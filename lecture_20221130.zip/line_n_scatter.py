#!/usr/bin/env python3
"""
Program: .py
Programmer: Aamir Alaud Din, PhD
Date: 2022.11.13

"""
import matplotlib.pyplot as plt

x = [-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5]
y = []
for i in x:
	y.append(i**2)

plt.plot(x, y, 'k', label="Parabola")
plt.scatter(x, y, s=20, c='b', marker='o', label="Points")
plt.xlabel("x-axis")
plt.ylabel("y-axis")
plt.title("Plot of y vs x")
plt.grid()
plt.legend()
plt.show()
