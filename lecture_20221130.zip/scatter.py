#!/usr/bin/env python3
"""
Program: .py
Programmer: Aamir Alaud Din, PhD
Date: 2022.11.13

"""
import random as random
import matplotlib.pyplot as plt

x = []
y = []
for i in range(25):
	x.append(random.random())
	y.append(random.random())

plt.scatter(x, y, s=50, c='b', marker='o')
plt.xlabel("x-axis")
plt.ylabel("y-axis")
plt.title("Plot of y vs x")
plt.grid()
plt.show()
