#!/usr/bin/env python3
"""
Program: .py
Programmer: Aamir Alaud Din, PhD
Date: 2022.11.13

"""
import matplotlib.pyplot as plt

x = [-3, -2, -1, 0, 1, 2, 3]
y1 = []
y2 = []
for i in x:
	y1.append(2*i - 1)
	y2.append(-2*i + 1)

plt.plot(x, y1, '-k', label='y1: Positive Slope')
plt.plot(x, y2, '-b', label='y2: Negative Slope')
plt.xlabel("x-axis")
plt.ylabel("y-axis")
plt.title("Plot of y1 and y2 vs x")
plt.grid()
plt.legend()
plt.show()
