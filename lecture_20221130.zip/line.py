#!/usr/bin/env python3
"""
Program: .py
Programmer: Aamir Alaud Din, PhD
Date: 2022.11.13

"""
import matplotlib.pyplot as plt


x = [-3, -2, -1, 0, 1, 2, 3]
y = []
for i in x:
	y.append(2*i -1)

plt.plot(x, y)
plt.show()

plt.plot(x, y, '-k')
plt.show()

plt.plot(x, y, '--r')
plt.show()

plt.plot(x, y, '-k', label="First Line")
plt.xlabel("x-axis")
plt.ylabel("y-axis")
plt.title("Plot of y vs x")
plt.grid()
plt.xlim([-3, 3])
#plt.ylim([-7, 4])
plt.ylim([2*min(x) - 1, 2*max(x) - 1])
plt.legend()
plt.show()
